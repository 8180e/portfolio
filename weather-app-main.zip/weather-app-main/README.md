Weather App by 8180e

HOW TO USE?

1. Extract the files
2. Run the "app.py" script
3. Type "localhost:5000" in a browser

Real Time Weather Forecast App
This project is a web application that provides real-time weather data for a specific city using the OpenWeatherMap API.Developed with the Flask framework, it allows users to access temperature, humidity, wind speed and 5-day weather forecasts by entering the city name. With IP-based location detection, instant weather information for the city where the user is located is also displayed.


Features:
Instant and 5-day weather forecast with OpenWeatherMap API integration.
IP-based automatic city detection.
Dynamic and user-friendly interface with the Flask framework.
Processing of weather data in JSON format and updating with AJAX.
Advanced error management and modular structure.
This project is a fully-featured application that showcases my API usage, web development and data processing skills.
